#!/bin/bash

# check permissions
if [[ "$(whoami)" != "root" ]]
then
    echo "Run under root"
    exit 1
fi

# apt
apt update > /dev/null 2> /dev/null
apt install -y python2 python2-dev libpython2.7 libnetfilter-queue1 libnetfilter-queue-dev screen wget

if [[ $? -ne 0 ]]
then
    exit 1
fi

# scapy
curl https://bootstrap.pypa.io/pip/2.7/get-pip.py --output get-pip.py
python2 get-pip.py
rm get-pip.py

pip2 install NetfilterQueue scapy

if [[ $? -ne 0 ]]
then
    exit 1
fi

# /etc/tcp-os
mkdir /etc/tcp-os
mkdir /etc/tcp-os/current-cfg
mkdir /etc/tcp-os/cmd-queue

cp install_data/p0f-spoof.py /etc/tcp-os/
cp install_data/signatures.lst /etc/tcp-os/
cp install_data/tcp-os-up.sh /etc/tcp-os/
cp install_data/tcp-os-down.sh /etc/tcp-os/
cp install_data/tcp-os-change.sh /etc/tcp-os/

chmod +x /etc/tcp-os/p0f-spoof.py
chmod +x /etc/tcp-os/*.sh
ln -s /etc/tcp-os/tcp-os-change.sh /usr/bin/tcp-os-change

# service
cp install_data/tcp-os.service /etc/systemd/system/
systemctl enable tcp-os.service
