#!/usr/bin/python2

from netfilterqueue import NetfilterQueue
from pprint import pprint
from scapy.all import *

import sys

def pkt_callback(payload):
    global fields, ts_index, mss_index
    data = payload.get_payload()
    pkt = IP(data)
    
    if pkt.proto is 0x06 and int(pkt[TCP].flags) is 2:
        #print('-' * 20)
        #pprint(pkt)
        #print('-' * 20)
        
        # IP
        if 'ttl' in fields.keys():
            pkt[IP].ttl = fields['ttl']
            
        if 'id+' in fields.keys():
            if pkt[IP].id == 0:
                pkt[IP].id = 1
        else:
            pkt[IP].id = 0
        
        pkt[IP].flags = 'DF'
        pkt[IP].frag = 0
            
        del pkt[IP].len
        del pkt[IP].chksum
        
        # TCP
        if 'window' in fields.keys():
            pkt[TCP].window = fields['window']
            
        if 'options' in fields.keys():
            orig_ts_index = -1
            orig_mss_index = -1
            
            for i in range(len(pkt[TCP].options)):
                if pkt[TCP].options[i][0] == 'Timestamp':
                    orig_ts_index = i
                if pkt[TCP].options[i][0] == 'MSS':
                    orig_mss_index = i
            
            if ts_index >= 0 and orig_ts_index >= 0:
                fields['options'][ts_index] = pkt[TCP].options[orig_ts_index]
            
            if mss_index >= 0 and fields['options'][mss_index][1] == 0:
                if orig_mss_index >= 0:
                    fields['options'][mss_index] = pkt[TCP].options[orig_mss_index]
                else:
                    fields['options'][mss_index] = ('MSS', 1460)
            
            pkt[TCP].options = fields['options']
            
        del pkt[TCP].dataofs
        del pkt[TCP].chksum
        
        # set_payload
        newpkt = IP(bytes(pkt))
        payload.set_payload(bytes(newpkt))
        
        global queue_NUM, os_signature
        
        #with open("/var/log/" + str(queue_NUM) + "-" + os_signature + ".log", "a+") as myfile:
        #    myfile.write(newpkt.sprintf("%IP.src% %TCP.options%") + "\n")
        
        #pprint(newpkt)
        #print('-' * 20)
        
    payload.accept()

def parse_os_signature(os_signature):
    sig_line = None
    
    try:
        for line in open('/etc/tcp-os/signatures.lst'):
            if len(line.strip()) == 0 or line.strip()[0] == '#':
                continue
            
            if re.split('[\s|\t]+', line.strip())[0] == os_signature:
                sig_line = re.split('[\s|\t]+', line.strip())[1].strip()
                break
        
        if sig_line == None:
            return None
        
        result = { }
        
        for field in sig_line.split(';'):
            field_pair = field.strip().split('=')
            
            if field_pair[0].strip() == 'options':
                options = [ ]
                
                for opt in field_pair[1].split(','):
                    opt_pair = opt.strip().split(':')
                    
                    if opt_pair[0].strip() == 'mss':
                        if len(opt_pair) > 1:
                            options.append(('MSS', int(opt_pair[1])))
                        else:
                            options.append(('MSS', 0))
                    elif opt_pair[0].strip() == 'nop':
                        options.append(('NOP', None))
                    elif opt_pair[0].strip() == 'wscale':
                        options.append(('WScale', int(opt_pair[1])))
                    elif opt_pair[0].strip() == 'timestamp':
                        options.append(('Timestamp', (0, 0)))
                    elif opt_pair[0].strip() == 'sackok':
                        options.append(('SAckOK', ''))
                    elif opt_pair[0].strip() == 'eol':
                        options.append(('EOL',''))
                    
                result['options'] = options
            else:
                if len(field_pair) > 1:
                    result[field_pair[0].strip()] = int(field_pair[1])
                else:
                    result[field_pair[0].strip()] = None
            
    except Exception as e:
        print e
        return None
    
    return result
    
### main ###
global queue_NUM
queue_NUM = int(sys.argv[1])
print queue_NUM

global os_signature
os_signature = sys.argv[2].lower()
print os_signature

global fields
fields = parse_os_signature(os_signature)
    
if fields == None:
    print 'Undefined signature', os_signature
    exit(1)
    
global ts_index
ts_index = -1

for i in range(len(fields['options'])):
    if fields['options'][i][0] == 'Timestamp':
        ts_index = i
        break
        
global mss_index
mss_index = -1

for i in range(len(fields['options'])):
    if fields['options'][i][0] == 'MSS':
        mss_index = i
        break

nfqueue = NetfilterQueue()
nfqueue.bind(queue_NUM, pkt_callback)

#with open("/var/log/" + str(queue_NUM) + "-" + os_signature + ".log", "a+") as myfile:
#    myfile.write("Started\n")
    
try:
    nfqueue.run()
except KeyboardInterrupt:
    print('')

nfqueue.unbind()
