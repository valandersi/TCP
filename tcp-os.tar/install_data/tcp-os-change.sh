#!/bin/bash

### main ###

# usage
if [[ $# -gt 2 ]]
then
    echo "Usage: tcp-os-change.sh [iface] [signature-name]"
    exit 1
fi

# without args
if [[ $# -lt 2 ]]
then
    echo "Usage: tcp-os-change.sh [iface] [signature-name]"
	
    pad=$(printf '%0.1s' " "{1..30})
    
    for IFACE in $(ls /etc/tcp-os/current-cfg/)
    do
        VAL=$(cat /etc/tcp-os/current-cfg/$IFACE)
        
        printf '%s' "$IFACE"
        printf '%*.*s' 0 $((30 - ${#IFACE} - ${#VAL} )) "$pad"
        printf '%s\n' "$VAL"
    done
    
    exit 0
fi

# check permissions
if [[ "$(whoami)" != "root" ]]
then
    echo "Run under root"
    exit 1
fi

# check iface
if [[ ! -d /sys/class/net/$1 ]]
then
    echo "$1 doesn't exist"
    exit 1
fi

# check signature-name
if [[ "$2" != "default" && "$(cat /etc/tcp-os/signatures.lst | grep "^$2 ")" == "" ]]
then
    echo "Signature $2 is not specified"
    exit 1
fi

# with 2 args
if [[ $# -eq 2 ]]
then
	if [[ "$2" == "default" ]]
	then
		rm "/etc/tcp-os/current-cfg/$1" 2> /dev/null
	else
		echo -n "$2" > /etc/tcp-os/current-cfg/$1
	fi
		
	echo -n "spoof-script-restart $1" > /etc/tcp-os/cmd-queue/$(date +%s%N).cmd
    exit $?
fi

exit 0
