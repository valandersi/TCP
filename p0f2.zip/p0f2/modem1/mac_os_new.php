<?php
$ssh_host = "192.168.1.75"; //адрес сервера, где будем выполнять команду
$ssh_port = "22"; //порт для подключения по ssh, обычно, он 22
$ssh_login = "pi"; //логин пользователя
$ssh_pass = "raspberry"; //пароль

$output = shell_exec('ip addr show');
$modem_ip = "192.168.150.1";

# для рандома
$os_array = ['ios_new', 'ios_old', 'mac_os_new', 'mac_os_old', 'android_new', 'android_old', 'win10', 'win8', 'win7'];
$key = array_rand($os_array);
$value_rand = $os_array[$key];

$matches = preg_split("/{$modem_ip}/", $output);
  if(sizeof($matches) > 1) {
    preg_match_all("/eth[0-9]{1,3}/", $matches[0], $m);
#    print_r($m[0][array_key_last($m[0])]);

    $ssh_command = "sudo tcp-os-change {$m[0][array_key_last($m[0])]} mac_os_new";
    #$ssh_command = "sudo tcp-os-change {$m[0][array_key_last($m[0])]} {$value_rand}";

        if($ssh = ssh2_connect($ssh_host, $ssh_port)) {
            if(ssh2_auth_password($ssh, $ssh_login, $ssh_pass)) {
                $stream = ssh2_exec($ssh, $ssh_command);
                stream_set_blocking($stream, true);
                $data = '';
                                        while($buffer = fread($stream, 4096)) {
                          $data .= $buffer;
                                        }
                    fclose($stream);
                    echo "<h2>Сменили!</h2>";

                        }
                }

}       else {
        echo '<h2>Не сменили!</h2>';
    }

?>