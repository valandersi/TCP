#!/bin/bash

# get os by iface name
function iface-os {
    if [[ $# -lt 1 ]]
    then
        return 1
    fi
    
    if [[ ! -f /etc/tcp-os/current-cfg/$1 ]]
    then
        echo -n "default"
		return 0
    fi
    
    cat /etc/tcp-os/current-cfg/$1
    return 0
}

# get iface id
function iface-id {
    if [[ $# -lt 1 ]]
    then
        return 1
    fi
	
    if [[ ! -f /etc/tcp-os/iface-id.lst ]]
    then
        touch /etc/tcp-os/iface-id.lst
    fi
	
	NUM=$(cat /etc/tcp-os/iface-id.lst | grep -oP "(?<=^$1\s)\d+")
	
	if [[ "$NUM" != "" ]]
	then
		echo -n $NUM
		return 0
	fi
	
	NUM=1
	
	while [[ "$(cat /etc/tcp-os/iface-id.lst | grep -oP "\s$NUM$")" != "" ]]
	do
		NUM=$((NUM+1))
	done
	
	echo "$1 $NUM" >> /etc/tcp-os/iface-id.lst
	echo -n $NUM
	return 0
}

# stop all
function stop-all {
    kill $(ps -eo pid,cmd | grep -i "screen -dmS p0f-spoof" | grep -v grep | grep -oP "^\s*\d+") 2> /dev/null
    
    OIFS=$IFS
    IFS=$'\n'
    for RULE in $(/usr/sbin/iptables -S | grep -oP "OUTPUT.*\-j\sNFQUEUE\s\-\-queue\-num\s\d+")
    do
        IFS=$OIFS
        /usr/sbin/iptables -D $RULE
		IFS=$'\n'
    done
    IFS=$OIFS
}

# restart spoofing script
function spoof-script-restart {
    if [[ $# -lt 1 ]]
    then
        return 1
    fi
	
    SCREEN_PROC=$(ps -eo pid,cmd | grep -i "screen -dmS p0f-spoof-$1 /" | grep -v grep)
    
    if [[ "$SCREEN_PROC" != "" ]]
    then
		SCREEN_PID=$(echo $SCREEN_PROC | grep -oP "^\s*\d+")
		kill $SCREEN_PID
    fi
    
	# check signature-name
	IFACE_OS=$(iface-os $1)
	
	if [[ "$IFACE_OS" == "default" ]]
	then
		/usr/sbin/iptables -D OUTPUT -o $1 -p tcp --tcp-flags SYN,ACK,FIN,RST SYN -j NFQUEUE --queue-num $ID > /dev/null 2> /dev/null
        return 0
	fi
	
	if [[ "$(cat /etc/tcp-os/signatures.lst | grep "^$IFACE_OS ")" == "" ]]
	then
		echo "WARNING: signature $IFACE_OS is not specified, fallback to default"
        return 0
	fi
	
	# iface id
	ID=$(iface-id $1)
	
    # add iptables rule
    if ! $(/usr/sbin/iptables -C OUTPUT -o $1 -p tcp --tcp-flags SYN,ACK,FIN,RST SYN -j NFQUEUE --queue-num $ID > /dev/null 2> /dev/null)
    then
        /usr/sbin/iptables -A OUTPUT -o $1 -p tcp --tcp-flags SYN,ACK,FIN,RST SYN -j NFQUEUE --queue-num $ID
    fi
	
	# start p0f-spoof
    sleep 1
    screen -dmS p0f-spoof-$1 /usr/bin/python2 /etc/tcp-os/p0f-spoof.py $ID $IFACE_OS
}

### main ###

# check permissions
if [[ "$(/usr/bin/whoami)" != "root" ]]
then
    echo "Run under root"
    exit 1
fi

# stop all
stop-all
sleep 1

# loop through ifaces current config
for IFACE in $(ls /etc/tcp-os/current-cfg/)
do
	# check iface
	if [[ ! -d /sys/class/net/$IFACE ]]
	then
		echo "WARNING: $IFACE doesn't exist, skipping..."
		continue
	fi
	
	# iface id
	ID=$(iface-id $IFACE)
	
	# check signature-name
	IFACE_OS=$(iface-os $IFACE)
	
	if [[ "$IFACE_OS" == "default" ]]
	then
		continue
	fi
	
	if [[ "$(cat /etc/tcp-os/signatures.lst | grep "^$IFACE_OS ")" == "" ]]
	then
		echo "WARNING: signature $IFACE_OS is not specified, fallback to default"
		continue
	fi
	
    # add iptables rule
    if ! $(/usr/sbin/iptables -C OUTPUT -o $IFACE -p tcp --tcp-flags SYN,ACK,FIN,RST SYN -j NFQUEUE --queue-num $ID > /dev/null 2> /dev/null)
    then
        /usr/sbin/iptables -A OUTPUT -o $IFACE -p tcp --tcp-flags SYN,ACK,FIN,RST SYN -j NFQUEUE --queue-num $ID
    fi
    
	# start p0f-spoof
	screen -dmS p0f-spoof-$IFACE /usr/bin/python2 /etc/tcp-os/p0f-spoof.py $ID $IFACE_OS
done

# executing commands loop
rm /etc/tcp-os/cmd-queue/* 2> /dev/null

while [[ 1 ]]
do
	for CMD in $(ls /etc/tcp-os/cmd-queue/ | grep -P "^\d+\.cmd$")
	do
		COMMAND=$(cat /etc/tcp-os/cmd-queue/$CMD | head -n 1)
		ARG_0=$(echo $COMMAND | cut -f 1 -d " ")
		ARG_1=$(echo $COMMAND | cut -f 2 -d " ")
		
		rm /etc/tcp-os/cmd-queue/$CMD
		
		# change os fingerprint
		if [[ "$ARG_0" == "spoof-script-restart" && "$ARG_1" != "" ]]
		then
			echo "Change OS fingerprint for $ARG_1"
			spoof-script-restart $ARG_1
		fi
	done
	
	sleep 1
done
