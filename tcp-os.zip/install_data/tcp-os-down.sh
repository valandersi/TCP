#!/bin/bash

# stop all
function stop-all {
    kill $(ps -eo pid,cmd | grep -i "screen -dmS p0f-spoof" | grep -v grep | grep -oP "^\s*\d+") 2> /dev/null
    
    OIFS=$IFS
    IFS=$'\n'
    for RULE in $(/usr/sbin/iptables -S | grep -oP "OUTPUT.*\-j\sNFQUEUE\s\-\-queue\-num\s\d+")
    do
        IFS=$OIFS
        /usr/sbin/iptables -D $RULE
		IFS=$'\n'
    done
    IFS=$OIFS
}

### main ###

# check permissions
if [[ "$(/usr/bin/whoami)" != "root" ]]
then
    echo "Run under root"
    exit 1
fi

# kill all
stop-all
